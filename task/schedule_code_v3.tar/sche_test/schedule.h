#ifndef TASK_SCHED_H
#define TASK_SCHED_H

/*
 *  *File Name 	: schedule.h 
 *   *
 *    *Description	: This file is description of quote task schedule
 *     * 
 *      *Author 		: He Wen Guan
 *       *
 *        *Time 			: 2015-8-20
 *         *
 *          *Copyright (c) 2007-2015 MY Capital Inc.
 *           *
 *            * */
 
#ifdef __cplusplus

extern "C"

{
#endif
 
#include <stdio.h>
#include <stdint.h>
#include <malloc.h>
#include <string.h>
#include <syslog.h>

#define     MAX_TASK_NUM    50 
#define     ITEM_LEN        8
#define     Start_day       153 
#define     CONTRACT_LEN    8
#define		TEST_NUM		3

struct day_schedule {
	uint32_t 	date_key;
	char 		item[8];
	uint32_t 	rank;
	char 		contract[8];
} day_schedule_t;

struct task_node {
	uint32_t 	deep;
	uint32_t 	cur_sub_index;
	char 		item[8];
	uint32_t 	rank;
	struct day_schedule  *next_sub_task;
}task_node_t;

typedef struct task {
	uint32_t beg_date;
	uint32_t end_date;
	char 	item[8];
	uint32_t rank;
}task_t;

typedef struct task_sched {
	struct task_node	*task_array;	
	struct quote_map 	*query_index;
} task_sched_t ;

typedef struct task_sched_cfg {
	char quote_origin_data_path[128];
	char quote_item_path[128];
} task_sched_cfg_t;

struct task_sched*
task_sched_init(task_sched_cfg_t* cfg);

/*
 *  * return task id
 *   * >= 0 : valid task id
 *    * <0   : invalid task id 
 *     */
int
task_sched_add(struct task_sched* ts, task_t* task);

int
task_sched_del(struct task_sched* ts, int task_id);

void
task_sched_destroy(struct task_sched* ts);

void 
task_quote_sched_func(struct task_sched *ts);

extern uint32_t Is_Leap_year(uint32_t year );
extern uint32_t calculate_year_key( uint32_t date );
extern void quote_find_use_date_key(struct task_sched * qm,struct day_schedule *input );

#ifdef __cplusplus
}
#endif

#endif
